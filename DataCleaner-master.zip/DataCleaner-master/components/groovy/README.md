GroovyDataCleanerExtension
==========================

An extension to DataCleaner that allows scripting in the Groovy language.

Simply do a "mvn install" of this project, install it using the DataCleaner "options" dialog and off you go!

Just want to use the extension? Go to
http://datacleaner.org/extension/Groovy-DataCleaner/

Want to read about how it was built? Go to
http://kasper.eobjects.org/2012/12/how-to-build-groovy-datacleaner.html