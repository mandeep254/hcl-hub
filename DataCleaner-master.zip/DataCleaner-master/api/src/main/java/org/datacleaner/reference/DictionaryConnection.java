/**
 * DataCleaner (community edition)
 * Copyright (C) 2014 Neopost - Customer Information Management
 *
 * This copyrighted material is made available to anyone wishing to use, modify,
 * copy, or redistribute it subject to the terms and conditions of the GNU
 * Lesser General Public License, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this distribution; if not, write to:
 * Free Software Foundation, Inc.
 * 51 Franklin Street, Fifth Floor
 * Boston, MA  02110-1301  USA
 */
package org.datacleaner.reference;

import java.io.Closeable;
import java.util.Iterator;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public interface DictionaryConnection extends Closeable {
    boolean containsValue(String value);

    Iterator<String> getLengthSortedValues();

    Iterator<String> getAllValues();

    default Stream<String> lengthSortedStream() {
        final Iterable<String> iterable = this::getLengthSortedValues;
        return StreamSupport.stream(iterable.spliterator(), false);
    }

    default Stream<String> stream() {
        final Iterable<String> iterable = this::getAllValues;
        return StreamSupport.stream(iterable.spliterator(), false);
    }

    @Override
    void close();
}
